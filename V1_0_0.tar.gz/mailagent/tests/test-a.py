from mailagent.database.db import insert_message, fetch_all_messages

insert_message("aiagent@cook-il.us", "/ask", "What is RAG?")
print(fetch_all_messages())