from mailagent.handlers.help import handle_help

def test_help():
    print(handle_help())

if __name__ == "__main__":
    test_help()
