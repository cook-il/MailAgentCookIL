from mailagent.handlers.fact import handle_fact
from mailagent.database.db import fetch_unapproved_entries

def test_fact_submission():
    response = handle_fact(
        "The Illinois River flows west of Chicago.", 
        "aiagent@cook-il.us", 
        "Illinois Department of Natural Resources"
    )
    print("Handler Response:", response)

    entries = fetch_unapproved_entries()
    print("Unapproved Entries:")
    for e in entries:
        print(e)

if __name__ == "__main__":
    test_fact_submission()
