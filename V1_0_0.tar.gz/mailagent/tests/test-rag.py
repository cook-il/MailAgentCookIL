from mailagent.handlers.rag import handle_rag
from mailagent.database.db import fetch_unapproved_entries

def test_rag_submission():
    response = handle_rag(
        "Property tax caps in Cook County are governed by the PTELL law.",
        "aiagent@cook-il.us",
        "https://revenue.illinois.gov"
    )
    print("Handler Response:", response)

    entries = fetch_unapproved_entries()
    print("Unapproved Entries:")
    for e in entries:
        print(e)

if __name__ == "__main__":
    test_rag_submission()
