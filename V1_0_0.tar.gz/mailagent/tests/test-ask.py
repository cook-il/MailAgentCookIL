# mailagent/tests/test-ask.py

from mailagent.handlers.ask import handle_ask

def test_ask():
    result = handle_ask("What is the purpose of MailAgentCookIL?", "aiagent@cook-il.us")
    print(result)

if __name__ == "__main__":
    test_ask()
